# LIVE10 Android MVP

A peer-to-peer live trivia game show prototype inspired by the shared-live tension of scheduled quiz shows.

## What this build includes
- One APK for both Host and Player mode
- Friends can join from different networks/cities using a 4-digit room code
- No laptop game server and no same-Wi-Fi requirement
- WebRTC peer-to-peer gameplay via PeerJS public signaling (test/MVP use)
- 40 preloaded questions across categories and difficulty levels
- Auto-pick a balanced set of 10 or manually choose exactly 10
- Multiple-choice and typed-answer questions
- 10s or 15s answer timer
- Last-3-second warning beeps
- Knockout on wrong/no answer; eliminated players continue in spectator mode
- Live player/alive/answer-locked counts
- Savage-question callout
- Equal jackpot split and winner confetti
- "Maya" AI-host persona with Android text-to-speech and animated host UI
- Host can also join as a player on the same phone

## Networking note
This MVP uses public PeerJS signaling to establish direct WebRTC connections. It is good for friend testing but is not production infrastructure. A production version should use an authoritative hosted realtime backend, authenticated rooms, abuse protection, reconnection, anti-cheat controls, and server-side timing/scoring.

## Build APK
GitHub Actions runs automatically on pushes to `main` and uploads `LIVE10-debug-apk` containing `app-debug.apk`.
