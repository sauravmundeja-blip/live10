const $app = document.getElementById('app');
const BANK = [
{id:'q1',cat:'General',diff:'Easy',type:'mcq',q:'Which planet is known as the Red Planet?',o:['Venus','Mars','Jupiter','Mercury'],a:1},
{id:'q2',cat:'General',diff:'Easy',type:'mcq',q:'How many days are there in a leap year?',o:['364','365','366','367'],a:2},
{id:'q3',cat:'World',diff:'Easy',type:'mcq',q:'Which city is famous for the Eiffel Tower?',o:['Rome','Paris','Madrid','Vienna'],a:1},
{id:'q4',cat:'Science',diff:'Easy',type:'mcq',q:'What do bees collect from flowers?',o:['Salt','Nectar','Sand','Dew'],a:1},
{id:'q5',cat:'Sports',diff:'Easy',type:'mcq',q:'How many players are on the field for one football team at a time?',o:['9','10','11','12'],a:2},
{id:'q6',cat:'India',diff:'Easy',type:'mcq',q:'What is the national animal of India?',o:['Lion','Elephant','Bengal tiger','Leopard'],a:2},
{id:'q7',cat:'Movies',diff:'Easy',type:'mcq',q:'In The Lion King, what kind of animal is Simba?',o:['Tiger','Lion','Leopard','Wolf'],a:1},
{id:'q8',cat:'Fun',diff:'Easy',type:'mcq',q:'Which animal is famous for sleeping while floating on its back?',o:['Otter','Panda','Giraffe','Penguin'],a:0},
{id:'q9',cat:'General',diff:'Easy',type:'text',q:'Type the color you get when you mix blue and yellow.',answers:['green']},
{id:'q10',cat:'India',diff:'Easy',type:'text',q:'Type the capital city of India.',answers:['new delhi','delhi']},
{id:'q11',cat:'World',diff:'Medium',type:'mcq',q:'Which country has the maple leaf on its flag?',o:['Canada','Norway','Sweden','Finland'],a:0},
{id:'q12',cat:'Science',diff:'Medium',type:'mcq',q:'What is the chemical symbol for gold?',o:['Go','Gd','Au','Ag'],a:2},
{id:'q13',cat:'General',diff:'Medium',type:'mcq',q:'Which instrument has 88 keys on a standard version?',o:['Violin','Piano','Flute','Guitar'],a:1},
{id:'q14',cat:'Sports',diff:'Medium',type:'mcq',q:'In tennis, what is a score of zero called?',o:['Blank','Nil','Love','Duck'],a:2},
{id:'q15',cat:'India',diff:'Medium',type:'mcq',q:'Which Indian city is known as the Pink City?',o:['Udaipur','Jaipur','Jodhpur','Lucknow'],a:1},
{id:'q16',cat:'Movies',diff:'Medium',type:'mcq',q:'Who lives in a pineapple under the sea?',o:['Patrick','Nemo','SpongeBob','Dory'],a:2},
{id:'q17',cat:'World',diff:'Medium',type:'mcq',q:'Which ocean is the largest?',o:['Atlantic','Indian','Arctic','Pacific'],a:3},
{id:'q18',cat:'Science',diff:'Medium',type:'mcq',q:'What gas do plants primarily absorb from the atmosphere?',o:['Oxygen','Nitrogen','Carbon dioxide','Hydrogen'],a:2},
{id:'q19',cat:'Fun',diff:'Medium',type:'mcq',q:'Which of these animals cannot jump?',o:['Elephant','Cat','Rabbit','Kangaroo'],a:0},
{id:'q20',cat:'General',diff:'Medium',type:'text',q:'Type the largest mammal on Earth.',answers:['blue whale','the blue whale']},
{id:'q21',cat:'India',diff:'Medium',type:'mcq',q:'Which river flows through Delhi?',o:['Ganga','Yamuna','Narmada','Godavari'],a:1},
{id:'q22',cat:'Sports',diff:'Medium',type:'mcq',q:'What color jersey does the Tour de France overall leader wear?',o:['Green','Yellow','Red','Blue'],a:1},
{id:'q23',cat:'World',diff:'Hard',type:'mcq',q:'Which country has the most time zones when overseas territories are included?',o:['Russia','United States','France','China'],a:2},
{id:'q24',cat:'Science',diff:'Hard',type:'mcq',q:'Which blood type is commonly called the universal red-cell donor?',o:['AB positive','O negative','A negative','B positive'],a:1},
{id:'q25',cat:'General',diff:'Hard',type:'mcq',q:'Which language has the most native speakers worldwide?',o:['English','Spanish','Mandarin Chinese','Hindi'],a:2},
{id:'q26',cat:'India',diff:'Hard',type:'mcq',q:'The Konark Sun Temple is located in which Indian state?',o:['Odisha','Gujarat','Rajasthan','Tamil Nadu'],a:0},
{id:'q27',cat:'Sports',diff:'Hard',type:'mcq',q:'In cricket, what is the maximum number of runs normally scored from one legal delivery without overthrows?',o:['4','5','6','8'],a:2},
{id:'q28',cat:'Movies',diff:'Hard',type:'mcq',q:'Which film features the fictional country of Wakanda?',o:['Avatar','Black Panther','Dune','Aquaman'],a:1},
{id:'q29',cat:'World',diff:'Hard',type:'mcq',q:'Which is the smallest independent country in the world by area?',o:['Monaco','San Marino','Vatican City','Liechtenstein'],a:2},
{id:'q30',cat:'Science',diff:'Hard',type:'mcq',q:'Which part of the human cell contains most genetic material?',o:['Cell membrane','Nucleus','Ribosome','Cytoplasm'],a:1},
{id:'q31',cat:'Fun',diff:'Hard',type:'mcq',q:'Which common food can remain edible for thousands of years when sealed properly?',o:['Bread','Honey','Cheese','Rice'],a:1},
{id:'q32',cat:'General',diff:'Hard',type:'text',q:'Type the Roman numeral for 50.',answers:['l']},
{id:'q33',cat:'India',diff:'Medium',type:'mcq',q:'Which Indian state has the longest coastline?',o:['Kerala','Tamil Nadu','Gujarat','Maharashtra'],a:2},
{id:'q34',cat:'World',diff:'Medium',type:'mcq',q:'Which continent is crossed by both the Equator and the Prime Meridian?',o:['Asia','Africa','South America','Europe'],a:1},
{id:'q35',cat:'Science',diff:'Medium',type:'mcq',q:'Which organ pumps blood around the human body?',o:['Liver','Lung','Heart','Kidney'],a:2},
{id:'q36',cat:'Fun',diff:'Medium',type:'mcq',q:'A group of flamingos is commonly called what?',o:['A parade','A flamboyance','A sparkle','A chorus'],a:1},
{id:'q37',cat:'General',diff:'Easy',type:'mcq',q:'Which month has 28 days in a normal year?',o:['Only February','All of them','January','June'],a:1},
{id:'q38',cat:'Movies',diff:'Easy',type:'mcq',q:'Which fictional wizard has a lightning-shaped scar?',o:['Gandalf','Harry Potter','Merlin','Doctor Strange'],a:1},
{id:'q39',cat:'India',diff:'Hard',type:'mcq',q:'Which classical dance form originated in Kerala?',o:['Kathakali','Kathak','Odissi','Manipuri'],a:0},
{id:'q40',cat:'World',diff:'Hard',type:'mcq',q:'Which capital city sits on the River Danube?',o:['Madrid','Budapest','Lisbon','Oslo'],a:1}
];

const newId=()=>('randomUUID' in crypto?crypto.randomUUID():'d'+Date.now().toString(36)+Math.random().toString(36).slice(2));
const S = {mode:null,peer:null,conn:null,conns:new Map(),players:new Map(),deviceId:localStorage.live10Device||newId(),name:localStorage.live10Name||'',room:'',selected:[],game:null,timers:[],audio:null,hostPlay:true,prize:5000,duration:10,filter:'All',localAnswer:null};
localStorage.live10Device=S.deviceId;

function clearTimers(){S.timers.forEach(clearTimeout);S.timers=[];}
function setT(fn,ms){const t=setTimeout(fn,ms);S.timers.push(t);return t;}
function esc(s=''){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function normalize(s){return String(s||'').trim().toLowerCase().replace(/[^a-z0-9 ]/g,'').replace(/\s+/g,' ');}
function logo(){return `<div class="logo"><span>LIVE10</span></div><div class="tag">LIVE. ANSWER. SURVIVE.</div>`;}
function hostCard(line='Your AI host is ready.',talking=false){return `<div class="card hostWrap ${talking?'talking':''}"><div class="hostFace"></div><div><div class="hostName"><span class="liveDot"></span>Maya • AI Host</div><div class="hostLine">${esc(line)}</div></div></div>`;}
function speak(text){if(!text)return;try{HostVoice.speak(text);}catch(e){if('speechSynthesis'in window){speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.rate=1.03;u.pitch=1.08;u.lang='en-US';speechSynthesis.speak(u);}}}
function stopSpeak(){try{HostVoice.stop();}catch(e){if('speechSynthesis'in window)speechSynthesis.cancel();}}
function audioUnlock(){try{if(!S.audio)S.audio=new (window.AudioContext||window.webkitAudioContext)();if(S.audio.state==='suspended')S.audio.resume();}catch(e){}}
function beep(n){audioUnlock();if(!S.audio)return;const o=S.audio.createOscillator(),g=S.audio.createGain();o.frequency.value=500+(4-n)*180;g.gain.value=.055;o.connect(g);g.connect(S.audio.destination);o.start();o.stop(S.audio.currentTime+.11);}
function money(n){return '₹'+Math.round(n).toLocaleString('en-IN');}
function peerMissing(){return typeof Peer==='undefined';}

function home(){clearTimers();stopSpeak();S.mode=null;$app.innerHTML=logo()+`<div class="card hero"><div class="eyebrow">THE 10-QUESTION LIVE GAME SHOW</div><div class="big">One wrong answer.<br>You’re out.</div><div class="sub">Create a room or join friends anywhere over the internet. No laptop server. No same-Wi-Fi requirement.</div></div><button class="primary" onclick="showJoin()">JOIN A LIVE GAME</button><button class="secondary" onclick="showHostSetup()">HOST A GAME</button><div class="card"><b>Tonight’s test build</b><div class="sub" style="margin-top:6px">AI host Maya • 10-second countdown • elimination • spectators • live survivor count • winner split • 40 preloaded questions.</div></div><div class="footer">Beta networking uses peer-to-peer WebRTC with public signaling. All players need internet access.</div>`;}

function showJoin(msg=''){$app.innerHTML=logo()+`<div class="card"><div class="eyebrow">PLAYER</div><div class="big" style="font-size:26px">Join the room</div>${msg?`<div class="notice">${esc(msg)}</div>`:''}<label class="label">YOUR NAME</label><input id="pname" maxlength="24" value="${esc(S.name)}" placeholder="Saurabh"><label class="label">4-DIGIT ROOM CODE</label><input id="rcode" inputmode="numeric" maxlength="4" placeholder="4827"><button class="primary" onclick="joinRoom()">JOIN LIVE</button><button class="ghost" onclick="home()">BACK</button></div>`;}

function showHostSetup(){$app.innerHTML=logo()+hostCard('I’ll run the show. You choose the game.')+`<div class="card"><div class="eyebrow">HOST SETUP</div><label class="label">YOUR PLAYER NAME</label><input id="hname" maxlength="24" value="${esc(S.name||'Saurabh')}" placeholder="Saurabh"><div class="row"><div><label class="label">PRIZE</label><input id="prize" inputmode="numeric" value="5000"></div><div><label class="label">ANSWER TIME</label><select id="duration"><option value="10">10 sec</option><option value="15">15 sec</option></select></div></div><label class="label"><input id="hostplay" type="checkbox" checked style="width:auto;margin-right:8px"> I also want to play</label><button class="primary" onclick="questionPicker()">CHOOSE 10 QUESTIONS</button><button class="ghost" onclick="home()">BACK</button></div>`;}

function balancedPick(){
  const shuffle=a=>[...a].sort(()=>Math.random()-.5);
  const easy=shuffle(BANK.filter(q=>q.diff==='Easy')).slice(0,3);
  const med=shuffle(BANK.filter(q=>q.diff==='Medium')).slice(0,4);
  const hard=shuffle(BANK.filter(q=>q.diff==='Hard')).slice(0,3);
  return [...easy,...med,...hard].map(q=>q.id);
}

function questionPicker(){
  S.name=document.getElementById('hname')?.value.trim()||S.name||'Host';localStorage.live10Name=S.name;
  S.prize=Math.max(0,Number(document.getElementById('prize')?.value||5000));
  S.duration=Number(document.getElementById('duration')?.value||10);
  S.hostPlay=!!document.getElementById('hostplay')?.checked;
  if(!S.selected.length)S.selected=balancedPick();
  renderPicker();
}
function renderPicker(){
  const cats=['All',...new Set(BANK.map(q=>q.cat))];const list=BANK.filter(q=>S.filter==='All'||q.cat===S.filter);
  $app.innerHTML=logo()+`<div class="card"><div class="row"><div><div class="eyebrow">QUESTION BANK</div><div style="font-size:24px;font-weight:1000">Pick exactly 10</div></div><div style="text-align:right"><span class="pill ${S.selected.length===10?'good':'warn'}">${S.selected.length}/10 selected</span></div></div><div class="pillbar">${cats.map(c=>`<button class="small ${S.filter===c?'primary':'secondary'}" style="width:auto" onclick="setFilter('${c}')">${c}</button>`).join('')}</div><button class="secondary small" onclick="autoPick()">✨ AUTO PICK A BALANCED 10</button><div class="qgrid" style="margin-top:10px">${list.map(q=>`<label class="qitem ${S.selected.includes(q.id)?'selected':''}"><input type="checkbox" ${S.selected.includes(q.id)?'checked':''} onchange="toggleQ('${q.id}',this.checked)"><div><div class="qtxt">${esc(q.q)}</div><div class="meta">${q.cat} • ${q.diff} • ${q.type==='text'?'Typed answer':'Multiple choice'}</div></div></label>`).join('')}</div><button class="primary" ${S.selected.length===10?'':'disabled'} onclick="createRoom()">CREATE LIVE ROOM</button><button class="ghost" onclick="showHostSetup()">BACK</button></div>`;
}
function setFilter(c){S.filter=c;renderPicker();} function autoPick(){S.selected=balancedPick();renderPicker();}
function toggleQ(id,on){if(on&&S.selected.length<10)S.selected.push(id);else if(!on)S.selected=S.selected.filter(x=>x!==id);renderPicker();}
function picked(){return S.selected.map(id=>BANK.find(q=>q.id===id)).filter(Boolean);}

function randomRoom(){return String(Math.floor(1000+Math.random()*9000));}
function createRoom(){
  if(S.selected.length!==10)return; audioUnlock(); S.mode='host';S.room=randomRoom();clearTimers();
  if(peerMissing()){hostLobby('Peer networking could not load. Check internet and reopen the app.');return;}
  try{S.peer=new Peer('live10-'+S.room,{debug:0});}catch(e){hostLobby('Could not start peer networking.');return;}
  S.players.clear();S.conns.clear();
  if(S.hostPlay)S.players.set(S.deviceId,{id:S.deviceId,name:S.name||'Host',alive:true,answer:null,eliminatedAt:null,host:true,connected:true});
  S.peer.on('open',()=>hostLobby());
  S.peer.on('error',err=>{if(err.type==='unavailable-id'){S.room=randomRoom();try{S.peer.destroy();}catch(e){};createRoom();}else hostLobby('Network error: '+err.type);});
  S.peer.on('connection',conn=>{
    S.conns.set(conn.peer,conn);conn.on('data',m=>hostMessage(conn,m));conn.on('close',()=>{for(const p of S.players.values())if(p.peer===conn.peer)p.connected=false;broadcastLobby();});
  });
  hostLobby('Opening room…');
}
function hostMessage(conn,m){if(!m||!m.type)return;
  if(m.type==='join'){
    const id=m.deviceId||conn.peer;let p=S.players.get(id);if(!p)p={id,name:(m.name||'Player').slice(0,24),alive:true,answer:null,eliminatedAt:null,host:false,connected:true,peer:conn.peer};
    p.name=(m.name||p.name).slice(0,24);p.peer=conn.peer;p.connected=true;S.players.set(id,p);send(conn,{type:'joined',room:S.room,deviceId:id});broadcastLobby();
  } else if(m.type==='answer'&&S.game&&S.game.stage==='question'){
    const p=S.players.get(m.deviceId);if(!p||!p.alive||p.answer!==null||Date.now()>S.game.deadline)return;p.answer=m.answer;send(conn,{type:'answerAck',answer:m.answer});broadcastState();
  }
}
function send(conn,obj){try{if(conn&&conn.open)conn.send(obj);}catch(e){}}
function broadcast(obj){for(const c of S.conns.values())send(c,obj);}
function publicPlayers(){return [...S.players.values()].map(p=>({id:p.id,name:p.name,alive:p.alive,connected:p.connected,answered:p.answer!==null,eliminatedAt:p.eliminatedAt,host:p.host}));}
function broadcastLobby(){broadcast({type:'lobby',room:S.room,players:publicPlayers(),prize:S.prize});if(S.mode==='host'&&!S.game)hostLobby();}
function hostLobby(msg=''){
  const ps=[...S.players.values()];$app.innerHTML=logo()+hostCard('Room '+S.room+' is open. Bring everyone in — then I’ll take over.')+`<div class="card hero"><div class="eyebrow">ROOM CODE</div><div class="room">${S.room}</div><div class="sub">Friends can be anywhere. Open LIVE10 → Join → enter this code.</div></div>${msg?`<div class="notice">${esc(msg)}</div>`:''}<div class="card"><div class="row"><b>Players in lobby</b><span class="pill good">${ps.length}</span></div><div class="players" style="margin-top:12px">${ps.length?ps.map(p=>`<span class="player">${esc(p.name)}${p.host?' ★':''}</span>`).join(''):'<span class="sub">Waiting for players…</span>'}</div><div class="divider"></div><div class="sub">${money(S.prize)} prize • ${S.duration}s per question • 10 questions • AI host Maya</div><button class="primary" ${ps.length?'':'disabled'} onclick="startGame()">GO LIVE NOW</button><button class="danger" onclick="endHost()">CLOSE ROOM</button></div>`;
}
function endHost(){try{S.peer?.destroy();}catch(e){};S.peer=null;home();}

function joinRoom(){
  audioUnlock();const name=document.getElementById('pname').value.trim();const room=document.getElementById('rcode').value.trim();if(!name||!/^[0-9]{4}$/.test(room)){showJoin('Enter your name and a 4-digit room code.');return;}
  S.name=name;localStorage.live10Name=name;S.room=room;S.mode='player';clearTimers();
  if(peerMissing()){showJoin('Peer networking could not load. Check your internet and reopen the app.');return;}
  $app.innerHTML=logo()+`<div class="card hero"><div class="big" style="font-size:26px">Connecting to ${room}…</div><div class="sub">Finding the live host.</div></div>`;
  S.peer=new Peer();
  S.peer.on('open',()=>{S.conn=S.peer.connect('live10-'+room,{reliable:true});S.conn.on('open',()=>S.conn.send({type:'join',name:S.name,deviceId:S.deviceId}));S.conn.on('data',playerMessage);S.conn.on('close',()=>connectionLost());});
  S.peer.on('error',()=>connectionLost());setT(()=>{if(!S.conn?.open)connectionLost('Could not find room '+room+'. Check the code and make sure the host is still online.');},9000);
}
function connectionLost(msg='The host connection ended.'){$app.innerHTML=logo()+`<div class="card hero"><div class="big" style="font-size:26px">Connection lost</div><div class="sub">${esc(msg)}</div><button class="primary" onclick="showJoin()">TRY AGAIN</button></div>`;}
function playerMessage(m){if(!m)return;if(m.type==='joined'||m.type==='lobby'){S.lastLobby=m;renderPlayerLobby(m);}else if(m.type==='state'){S.game=m.state;renderGame(m.state,false);}else if(m.type==='finish'){S.game=m.state;renderGame(m.state,false);}}
function renderPlayerLobby(m){const ps=m.players||S.lastLobby?.players||[];$app.innerHTML=logo()+hostCard('You’re in. Stay here — we start together.')+`<div class="card hero"><div class="eyebrow">YOU’RE IN ROOM</div><div class="room">${S.room}</div><div class="big" style="font-size:25px">${ps.length} player${ps.length===1?'':'s'} ready</div><div class="sub">${money(m.prize||S.prize)} prize. The host controls the start.</div></div><div class="card"><div class="players">${ps.map(p=>`<span class="player">${esc(p.name)}${p.id===S.deviceId?' • YOU':''}</span>`).join('')}</div></div>`;}

function startGame(){
  if(!S.players.size)return;S.game={stage:'intro',index:-1,questions:picked(),hostNow:Date.now(),prize:S.prize,duration:S.duration,players:publicPlayers(),line:`Hellooo LIVE10! We have ${S.players.size} player${S.players.size===1?'':'s'} in the room and ${money(S.prize)} up for grabs. Ten questions. One wrong answer and you are out — but you can stay and watch. Let's play!`};
  broadcastState();renderGame(S.game,true);speak(S.game.line);setT(()=>startQuestion(0),8000);
}
function broadcastState(){if(!S.game)return;S.game.players=publicPlayers();S.game.hostNow=Date.now();broadcast({type:'state',state:sanitizeState(S.game)});}
function sanitizeState(g){const q=g.question?{id:g.question.id,cat:g.question.cat,diff:g.question.diff,type:g.question.type,q:g.question.q,o:g.question.o||null}:null;return {...g,questions:undefined,question:q};}
function alivePlayers(){return [...S.players.values()].filter(p=>p.alive);}
function startQuestion(i){
  if(i>=10){finishGame();return;}S.localAnswer=null;for(const p of S.players.values())p.answer=null;
  const q=S.game.questions[i];const line=`Question ${i+1} of ten. ${q.q}`;S.game={...S.game,stage:'hostQuestion',index:i,question:q,deadline:null,line,locked:false};broadcastState();renderGame(S.game,true);speak(line);
  const words=q.q.split(/\s+/).length;const readMs=Math.max(3500,Math.min(7000,1600+words*330));setT(()=>openQuestion(),readMs);
}
function openQuestion(){const q=S.game.questions[S.game.index];S.game.stage='question';S.game.question=q;S.game.deadline=Date.now()+S.duration*1000;S.game.line=`Your ${S.duration} seconds starts now.`;broadcastState();renderGame(S.game,true);speak(S.game.line);startCountdown(S.game,true);setT(()=>revealQuestion(),S.duration*1000+120);}
function localSubmit(ans){
  if(!S.game||S.game.stage!=='question')return;
  if(S.mode==='host'){
    const p=S.players.get(S.deviceId);if(!p||!p.alive||p.answer!==null)return;p.answer=ans;renderGame(S.game,true);broadcastState();
  } else {const me=(S.game.players||[]).find(p=>p.id===S.deviceId);if(!me?.alive)return;send(S.conn,{type:'answer',deviceId:S.deviceId,answer:ans});S.localAnswer=ans;renderGame(S.game,false);}
}
function submitTyped(){const v=document.getElementById('typedAnswer')?.value.trim();if(v)localSubmit(v);}
function grade(q,ans){if(ans===null||ans===undefined)return false;if(q.type==='mcq')return Number(ans)===q.a;return (q.answers||[]).map(normalize).includes(normalize(ans));}
function revealQuestion(){
  const q=S.game.questions[S.game.index];const before=alivePlayers().length;
  for(const p of S.players.values())if(p.alive&&!grade(q,p.answer)){p.alive=false;p.eliminatedAt=S.game.index;}
  const after=alivePlayers().length;const savage=before>2&&after/before<=.35;
  const correct=q.type==='mcq'?`${String.fromCharCode(65+q.a)}, ${q.o[q.a]}`:(q.answers?.[0]||'');
  S.game.stage='reveal';S.game.correct=q.type==='mcq'?q.a:(q.answers?.[0]||'');S.game.savage=savage;S.game.before=before;S.game.after=after;S.game.line=savage?`That was savage! Only ${after} player${after===1?'':'s'} survived. The correct answer was ${correct}.`:`Answers locked. The correct answer is ${correct}. ${after} player${after===1?' remains':'s remain'}.`;
  broadcastState();renderGame(S.game,true);speak(S.game.line);if(after===0){setT(()=>finishGame(),5800);}else setT(()=>startQuestion(S.game.index+1),5800);
}
function finishGame(){
  const winners=alivePlayers();const each=winners.length?S.prize/winners.length:0;S.game={...S.game,stage:'finish',players:publicPlayers(),winners:winners.map(p=>p.name),each,line:winners.length?`We have ${winners.length} winner${winners.length===1?'':'s'}! ${winners.map(p=>p.name).join(', ')}. You each win ${money(each)}. That is LIVE10!`:`Nobody survived tonight. The jackpot lives to fight another day!`};broadcast({type:'finish',state:sanitizeState(S.game)});renderGame(S.game,true);speak(S.game.line);
}

function meFrom(g){return (g.players||[]).find(p=>p.id===S.deviceId);}
function renderGame(g,isHost){
  clearCountdownOnly();const ps=g.players||publicPlayers();const alive=ps.filter(p=>p.alive).length;const answered=ps.filter(p=>p.alive&&p.answered).length;const me=isHost?S.players.get(S.deviceId):meFrom(g);const spectator=me&&!me.alive;
  let body=logo()+`<div class="topStats"><div class="stat"><b>${ps.length}</b><span>PLAYERS</span></div><div class="stat"><b>${alive}</b><span>ALIVE</span></div><div class="stat"><b>${money(g.prize||S.prize)}</b><span>JACKPOT</span></div></div>`;
  if(g.stage==='intro'){body+=hostCard(g.line,true)+`<div class="card hero"><div class="eyebrow">WE ARE LIVE</div><div class="big">Get ready.</div><div class="sub">Question 1 is coming up.</div></div>`;}
  else if(g.stage==='hostQuestion'){body+=hostCard(g.line,true)+`<div class="card stage"><div class="qno">QUESTION ${g.index+1} OF 10</div><div class="question">${esc(g.question.q)}</div><div class="sub">Maya is reading the question… timer starts after this.</div></div>`;}
  else if(g.stage==='question'){
    const locked=isHost?S.players.get(S.deviceId)?.answer!==null:S.localAnswer!==undefined&&S.localAnswer!==null;body+=hostCard(g.line,false)+`<div class="card stage"><div class="qno">QUESTION ${g.index+1} OF 10 • ${esc(g.question.cat)}</div><div class="question">${esc(g.question.q)}</div><div class="timer" id="timer"><span id="timerNum">${g.duration}</span></div>${spectator?`<div class="statusBanner spectator">👀 SPECTATOR MODE — you’re out, but stay for the chaos.</div>`:''}${!spectator?(g.question.type==='mcq'?`<div class="answers">${g.question.o.map((o,i)=>`<button class="answer ${(locked&&Number((isHost?S.players.get(S.deviceId)?.answer:S.localAnswer))===i)?'locked':''}" onclick="localSubmit(${i})" ${locked?'disabled':''}><b>${String.fromCharCode(65+i)}.</b> ${esc(o)}</button>`).join('')}</div>`:`<input id="typedAnswer" class="typed" placeholder="Type your answer" ${locked?'disabled':''}><button class="primary" onclick="submitTyped()" ${locked?'disabled':''}>LOCK ANSWER</button>`):''}${locked?`<div class="lockedMsg">🔒 ANSWER LOCKED</div>`:''}<div class="sub" style="margin-top:10px">${answered} answer${answered===1?'':'s'} locked</div></div>`;
    startCountdown(g,isHost);
  } else if(g.stage==='reveal'){
    const q=g.question;const myAnswer=isHost?S.players.get(S.deviceId)?.answer:S.localAnswer;const correct=gradeFullClient(q,g.correct,myAnswer);const justEliminated=me&&me.eliminatedAt===g.index;body+=hostCard(g.line,true)+`<div class="card stage">${g.savage?`<div class="statusBanner savage">⚡ SAVAGE QUESTION</div>`:''}<div class="qno">CORRECT ANSWER</div><div class="question">${q.type==='mcq'?`${String.fromCharCode(65+g.correct)}. ${esc(q.o[g.correct])}`:esc(g.correct)}</div>${me?(justEliminated?`<div class="statusBanner eliminated">💀 YOU’RE OUT — keep watching.</div>`:me.alive?`<div class="statusBanner survive">✅ YOU’RE STILL IN!</div>`:`<div class="statusBanner spectator">👀 SPECTATING</div>`):''}<div class="big" style="font-size:28px">${g.after} survived</div><div class="sub">${g.before-g.after} eliminated on this question</div></div>`;S.localAnswer=null;
  } else if(g.stage==='finish'){
    body+=hostCard(g.line,true)+`<div class="card hero"><div class="eyebrow">GAME OVER</div>${g.winners?.length?`<div class="big">🏆 ${g.winners.length} WINNER${g.winners.length===1?'':'S'}</div><div class="money">${money(g.each)} each</div><div style="margin-top:16px">${g.winners.map(n=>`<div class="winnerName">${esc(n)}</div>`).join('')}</div>`:`<div class="big">NO WINNERS 😵</div><div class="sub">Everyone got knocked out.</div>`}${isHost?`<button class="primary" onclick="hostAgain()">PLAY ANOTHER GAME</button>`:`<button class="primary" onclick="home()">BACK HOME</button>`}</div>${g.winners?.length?confetti():''}`;
  }
  $app.innerHTML=body;
}
function gradeFullClient(q,correct,ans){if(q.type==='mcq')return Number(ans)===Number(correct);return normalize(ans)===normalize(correct);}
let cd=null;function clearCountdownOnly(){if(cd){clearInterval(cd);cd=null;}}
function startCountdown(g,isHost){clearCountdownOnly();if(!g.deadline)return;let last=null;const tick=()=>{const left=Math.max(0,Math.ceil((g.deadline-Date.now())/1000));const el=document.getElementById('timer'),num=document.getElementById('timerNum');if(num)num.textContent=left;if(el){const pct=Math.max(0,Math.min(100,100*(g.deadline-Date.now())/(g.duration*1000)));el.style.setProperty('--pct',pct+'%');el.classList.toggle('hot',left<=3);}if(left<=3&&left>0&&left!==last)beep(left);last=left;if(left<=0){clearCountdownOnly();}};tick();cd=setInterval(tick,120);}
function confetti(){let x='<div class="confetti">';for(let i=0;i<55;i++)x+=`<i style="--x:${Math.random()*100}%;--h:${Math.random()*360};--d:${2.5+Math.random()*3}s;--r:${Math.random()*180}deg;animation-delay:${Math.random()*2}s"></i>`;return x+'</div>';}
function hostAgain(){S.game=null;for(const p of S.players.values()){p.alive=true;p.answer=null;p.eliminatedAt=null;}S.selected=balancedPick();broadcastLobby();hostLobby();}

window.addEventListener('beforeunload',()=>{try{S.peer?.destroy();}catch(e){}});
home();
