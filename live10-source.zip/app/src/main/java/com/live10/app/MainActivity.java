package com.live10.app;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        tts = new TextToSpeech(this, this);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(settings.getUserAgentString() + " LIVE10/0.2");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new HostVoiceBridge(), "HostVoice");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale.US);
            tts.setSpeechRate(1.03f);
            tts.setPitch(1.08f);
            chooseNaturalEnglishVoice();
            ttsReady = true;
        }
    }

    private void chooseNaturalEnglishVoice() {
        try {
            Set<Voice> voices = tts.getVoices();
            if (voices == null) return;
            Voice fallback = null;
            Voice preferred = null;
            for (Voice v : voices) {
                if (v.getLocale() == null || !"en".equalsIgnoreCase(v.getLocale().getLanguage())) continue;
                if (fallback == null && !v.isNetworkConnectionRequired()) fallback = v;
                String name = v.getName() == null ? "" : v.getName().toLowerCase(Locale.US);
                // Google/Samsung engines expose different names. Prefer an enhanced/network voice
                // when available; slightly raised pitch below keeps Maya bright without sounding cartoonish.
                if ((name.contains("female") || name.contains("sfg") || name.contains("iol") || name.contains("enhanced"))
                        && v.getLocale().toLanguageTag().toLowerCase(Locale.US).startsWith("en-us")) {
                    preferred = v;
                    break;
                }
            }
            if (preferred != null) tts.setVoice(preferred);
            else if (fallback != null) tts.setVoice(fallback);
        } catch (Exception ignored) { }
    }

    public class HostVoiceBridge {
        @JavascriptInterface
        public void speak(final String text) {
            runOnUiThread(() -> {
                if (!ttsReady || text == null || text.trim().isEmpty()) return;
                tts.stop();
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "live10-host");
            });
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(() -> {
                if (tts != null) tts.stop();
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
